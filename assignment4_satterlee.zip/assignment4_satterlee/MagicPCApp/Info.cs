﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace MagicPCApp
{
    class Info
    {
        public void MagicPCinfo()
        {
            WriteLine("**************************************************************");
            WriteLine();
            WriteLine("Name:            Paul Satterlee");
            WriteLine("Course:          ITDEV-115");
            WriteLine("Instructor:      Janese Christie");
            WriteLine("Assignment:      Magic PC App, Assignment 4");
            WriteLine("Date:            2/20/21");
            WriteLine();
            WriteLine("*************************************************************");
            WriteLine("Press Any Key to Continue");
            ReadKey();

        }
    }
}
