﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace assignment2_satterlee
{
    class Info
    {
        public void DisplayInfo()
        {
            WriteLine("**************************************************************************");
            WriteLine();
            WriteLine("Name:          Paul Satterlee");
            WriteLine("Course:        ITDEV-115");
            WriteLine("Instructor:    Janese Christie");
            WriteLine("Assignment:    Employee Payroll(Assignment 2)");
            WriteLine("Date:          2/4/2021");
            WriteLine();
            WriteLine("**************************************************************************");
        }
    }
}

