﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace ElectionProgram
{
    class Info
    {
        public void DisplayInfo()
        {
            WriteLine("*****************************************************");
            WriteLine();
            WriteLine("Name:          Paul Satterlee");
            WriteLine("Course:        IT-DEV 115");
            WriteLine("Instructor:    Janese Christie");
            WriteLine("Assignment:    Mid-Term - Election App");
            WriteLine("Date:          3/2/21");
            WriteLine();
            WriteLine("*****************************************************");
            WriteLine();
        }

    }
}
