﻿using System;

public class Info
{
    public void DisplayInfo()
    {
        WriteLine("*****************************************************");
        WriteLine();
        WriteLine("Name:          Paul Satterlee");
        WriteLine("Course:        IT-DEV 115");
        WriteLine("Instructor:    Janese Christie");
        WriteLine("Assignment:    5 - Student Study App");
        WriteLine("Date:          2/25/21");
        WriteLine();
        WriteLine("*****************************************************");
        WriteLine();
    }
}
