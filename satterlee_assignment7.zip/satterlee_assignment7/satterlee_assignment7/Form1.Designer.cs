﻿
namespace satterlee_assignment7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chickenN = new System.Windows.Forms.Button();
            this.grainN = new System.Windows.Forms.Button();
            this.foxN = new System.Windows.Forms.Button();
            this.grainS = new System.Windows.Forms.Button();
            this.chickenS = new System.Windows.Forms.Button();
            this.foxS = new System.Windows.Forms.Button();
            this.farmerN = new System.Windows.Forms.Button();
            this.farmerS = new System.Windows.Forms.Button();
            this.River = new System.Windows.Forms.Label();
            this.northBank = new System.Windows.Forms.Label();
            this.southBank = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // chickenN
            // 
            this.chickenN.Font = new System.Drawing.Font("Yu Gothic Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chickenN.Location = new System.Drawing.Point(345, 41);
            this.chickenN.Name = "chickenN";
            this.chickenN.Size = new System.Drawing.Size(114, 27);
            this.chickenN.TabIndex = 0;
            this.chickenN.Text = "CHICKEN";
            this.chickenN.UseVisualStyleBackColor = true;
            this.chickenN.Click += new System.EventHandler(this.chickenN_Click);
            // 
            // grainN
            // 
            this.grainN.Font = new System.Drawing.Font("Yu Gothic Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grainN.Location = new System.Drawing.Point(465, 41);
            this.grainN.Name = "grainN";
            this.grainN.Size = new System.Drawing.Size(114, 27);
            this.grainN.TabIndex = 1;
            this.grainN.Text = "GRAIN";
            this.grainN.UseVisualStyleBackColor = true;
            this.grainN.Click += new System.EventHandler(this.grainN_Click);
            // 
            // foxN
            // 
            this.foxN.Font = new System.Drawing.Font("Yu Gothic Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foxN.Location = new System.Drawing.Point(225, 41);
            this.foxN.Name = "foxN";
            this.foxN.Size = new System.Drawing.Size(114, 27);
            this.foxN.TabIndex = 2;
            this.foxN.Text = "FOX";
            this.foxN.UseVisualStyleBackColor = true;
            this.foxN.Click += new System.EventHandler(this.foxN_Click);
            // 
            // grainS
            // 
            this.grainS.Font = new System.Drawing.Font("Yu Gothic Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grainS.Location = new System.Drawing.Point(465, 300);
            this.grainS.Name = "grainS";
            this.grainS.Size = new System.Drawing.Size(114, 27);
            this.grainS.TabIndex = 3;
            this.grainS.Text = "GRAIN";
            this.grainS.UseVisualStyleBackColor = true;
            this.grainS.Click += new System.EventHandler(this.grainS_Click);
            // 
            // chickenS
            // 
            this.chickenS.Font = new System.Drawing.Font("Yu Gothic Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chickenS.Location = new System.Drawing.Point(345, 300);
            this.chickenS.Name = "chickenS";
            this.chickenS.Size = new System.Drawing.Size(114, 27);
            this.chickenS.TabIndex = 4;
            this.chickenS.Text = "CHICKEN";
            this.chickenS.UseVisualStyleBackColor = true;
            this.chickenS.Click += new System.EventHandler(this.chickenS_Click);
            // 
            // foxS
            // 
            this.foxS.Font = new System.Drawing.Font("Yu Gothic Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foxS.Location = new System.Drawing.Point(225, 300);
            this.foxS.Name = "foxS";
            this.foxS.Size = new System.Drawing.Size(114, 27);
            this.foxS.TabIndex = 5;
            this.foxS.Text = "FOX";
            this.foxS.UseVisualStyleBackColor = true;
            this.foxS.Click += new System.EventHandler(this.foxS_Click);
            // 
            // farmerN
            // 
            this.farmerN.Font = new System.Drawing.Font("Yu Gothic Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.farmerN.Location = new System.Drawing.Point(88, 41);
            this.farmerN.Name = "farmerN";
            this.farmerN.Size = new System.Drawing.Size(114, 27);
            this.farmerN.TabIndex = 6;
            this.farmerN.Text = "Farmer";
            this.farmerN.UseVisualStyleBackColor = true;
            this.farmerN.Click += new System.EventHandler(this.farmerN_Click);
            // 
            // farmerS
            // 
            this.farmerS.Font = new System.Drawing.Font("Yu Gothic Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.farmerS.Location = new System.Drawing.Point(88, 300);
            this.farmerS.Name = "farmerS";
            this.farmerS.Size = new System.Drawing.Size(114, 27);
            this.farmerS.TabIndex = 7;
            this.farmerS.Text = "Farmer";
            this.farmerS.UseVisualStyleBackColor = true;
            this.farmerS.Click += new System.EventHandler(this.farmerS_Click);
            // 
            // River
            // 
            this.River.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.River.AutoSize = true;
            this.River.BackColor = System.Drawing.Color.Blue;
            this.River.Font = new System.Drawing.Font("Yu Gothic", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.River.Location = new System.Drawing.Point(259, 123);
            this.River.Name = "River";
            this.River.Size = new System.Drawing.Size(277, 124);
            this.River.TabIndex = 8;
            this.River.Text = "River";
            // 
            // northBank
            // 
            this.northBank.AutoSize = true;
            this.northBank.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.northBank.Font = new System.Drawing.Font("Yu Gothic Medium", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.northBank.Location = new System.Drawing.Point(345, 90);
            this.northBank.Name = "northBank";
            this.northBank.Size = new System.Drawing.Size(97, 19);
            this.northBank.TabIndex = 9;
            this.northBank.Text = "North Bank";
            // 
            // southBank
            // 
            this.southBank.AutoSize = true;
            this.southBank.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.southBank.Font = new System.Drawing.Font("Yu Gothic Medium", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.southBank.Location = new System.Drawing.Point(344, 264);
            this.southBank.Name = "southBank";
            this.southBank.Size = new System.Drawing.Size(98, 19);
            this.southBank.TabIndex = 10;
            this.southBank.Text = "South Bank";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.southBank);
            this.Controls.Add(this.northBank);
            this.Controls.Add(this.River);
            this.Controls.Add(this.farmerS);
            this.Controls.Add(this.farmerN);
            this.Controls.Add(this.foxS);
            this.Controls.Add(this.chickenS);
            this.Controls.Add(this.grainS);
            this.Controls.Add(this.foxN);
            this.Controls.Add(this.grainN);
            this.Controls.Add(this.chickenN);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button chickenN;
        private System.Windows.Forms.Button grainN;
        private System.Windows.Forms.Button foxN;
        private System.Windows.Forms.Button grainS;
        private System.Windows.Forms.Button chickenS;
        private System.Windows.Forms.Button foxS;
        private System.Windows.Forms.Button farmerN;
        private System.Windows.Forms.Button farmerS;
        private System.Windows.Forms.Label River;
        private System.Windows.Forms.Label northBank;
        private System.Windows.Forms.Label southBank;
    }
}

